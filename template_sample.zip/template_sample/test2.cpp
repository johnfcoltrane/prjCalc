#include <iostream>

using namespace std;

typedef int ar3_t[3][4];

typedef 
    int (*funcp_t)(int, int);

void test1(funcp_t a, int n, int m){
//void test1(int &a[3][3]){
    //int n = sizeof(ar3_t)/sizeof(a[0]);
    for(int i=0; i<n; i++){
        //int m = sizeof(a[0])/sizeof(a[0][0]);
        for(int j=0; j<m; j++){
            cout << " " << a(i, j) ;
        }
        cout << endl;
    }
}

//int a[3][4] = {
ar3_t a = {
    {1,2,3,4},
    {4,5,6,7},
    {7,8,9,10}
};

int main(){

    cout << "** Hello! **" << endl;
    cout << sizeof(a) << endl;

    //funcp_t fnc = [](int i,int j){return(a[i][j]);};

    test1([](int i,int j){return(a[i][j]);},
        3, 4);
}