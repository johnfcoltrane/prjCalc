#include <iostream>

using namespace std;

// 関数ポインタの定義
#if 0
template<typename ret_t>
    typedef ret_t (*myAddFunc_t)(int, int);
#else
    typedef int (*myAddFunc_t)(int, int);
#endif
void funcTest(myAddFunc_t f1){
    cout << "funcTest: " << f1(1,19) << endl;
}

int main(){

    myAddFunc_t myAdd;
    // lambda式の定義
    myAdd = [](int i,int j){return(i+j);};

    cout << "** Hello! **" << endl;
    cout << myAdd(10,20) << endl;

    funcTest(myAdd);

}