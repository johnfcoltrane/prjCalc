#include "stdio.h"
#include <iostream>

using namespace std;

void main(void) {

	//printf("Hello World\n");
	cout << "!!! Hello !!!" << endl;
	
	
}
