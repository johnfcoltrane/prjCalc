#include <iostream>
#include <vector>

using namespace std;

typedef struct {
    unsigned int r;
    unsigned int g;
    unsigned int b;
} st_t;

typedef vector<int> Vec1_t;
typedef vector<Vec1_t> VecVec_t;

int a[3][4] = {
    {1,2,3,4},
    {5,6,7,8},
    {9,10,11,12},
};

void dumpV(VecVec_t& vv){
    int n = vv.size();
    for(int i=0; i<n; i++){
        int m = vv[i].size();
        for(int j=0; j<m; j++){
            int x = vv[i][j];
            cout << " " << x ;
        }
        cout << endl;
    }
}
void test1(){
    VecVec_t vv;
    cout << "** test1 **" << endl;
    vv.push_back(vector<int>());    //vv[0] <- vector<int>
    vv[0].push_back(123);           //vv[0][0]=123;
    cout << vv[0][0] << endl;
}
#if 0
template<typename retType>
typedef retType (*func_t)(int i, int j);
#else
typedef int (*func_t)(int i, int j);
#endif
template<typename type_t>
void push_data(vector<vector<type_t>>& vv, int n, int m, func_t func)
{
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if (j==0){ vv.push_back(vector<type_t>()); }
            vv[i].push_back(func(i,j));
        }
    }
}

int main(){
    //test1();
    vector<vector<int>> vv;
    cout << "** Hello! **" << endl;
    //typedef int (*func_t)(int i, int j);
    func_t func = [](int i,int j){ return(a[i][j]); };
    push_data<int>(vv, 3, 4, func);
    cout << "---------------" << endl;
    dumpV(vv);
}